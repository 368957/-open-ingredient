import os, tempfile
from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
def test_health():
 r=client.get('/health'); assert r.status_code==200 and r.json()['status']=='ok'
def test_invalid_barcode():
 r=client.get('/api/v1/products/barcode/not-a-barcode'); assert r.status_code==422
def test_filters_warn_about_unknown_allergens():
 j=client.get('/api/v1/filters').json(); assert '不等于无过敏原' in j['note']
def test_ingredient_without_evidence_is_not_asserted_as_fact():
 j=client.get('/api/v1/ingredients/unknown-additive').json(); assert j['evidence_status']=='insufficient_evidence' and j['source_ids']==[]
def test_ocr_rejects_non_image():
 r=client.post('/api/v1/ocr/ingredients',files={'file':('x.txt',b'hello','text/plain')}); assert r.status_code==415
def test_contribution_validation():
 r=client.post('/api/v1/contributions',json={'contribution_type':'bogus','payload':{}}); assert r.status_code==422

def test_compare_rejects_wrong_number_of_barcodes():
    r=client.get('/api/v1/products/compare?ids=12345678'); assert r.status_code==422


def test_ocr_uses_local_provider_and_never_persists_image():
    from PIL import Image
    import io
    image = Image.new("RGB", (180, 60), "white")
    buf = io.BytesIO(); image.save(buf, format="PNG")
    r = client.post('/api/v1/ocr/ingredients', files={'file': ('label.png', buf.getvalue(), 'image/png')})
    assert r.status_code == 200
    j = r.json()
    assert j['provider'] in {'tesseract', 'none'}
    assert j['image_persisted'] is False and j['requires_user_confirmation'] is True

def test_contribution_can_be_created_and_status_checked():
    payload = {'contribution_type':'ingredient_correction','product_barcode':'12345678','payload':{'ingredients_text':'test fixture only'}}
    r = client.post('/api/v1/contributions', json=payload)
    assert r.status_code == 202
    created = r.json()
    assert created['status'] == 'pending'
    status = client.get('/api/v1/contributions/' + created['id'])
    assert status.status_code == 200 and status.json()['status'] == 'pending'


def test_rule_analysis_marks_missing_allergens_as_unknown_without_health_score():
    r = client.post('/api/v1/analysis/rules', json={'product': {'name': 'fixture food'}})
    assert r.status_code == 200
    data = r.json()
    assert data['health_score'] is None
    codes = {item['code'] for item in data['warnings']}
    assert {'missing_ingredients', 'missing_nutrition', 'allergens_unknown', 'missing_source'} <= codes
    assert '不代表无过敏原' in next(x['message'] for x in data['warnings'] if x['code'] == 'allergens_unknown')


def test_rule_analysis_reports_source_disagreement_without_auto_resolution():
    r = client.post('/api/v1/analysis/rules', json={
        'product': {'name': 'fixture food', 'barcode': '12345678'},
        'source_records': [
            {'source_name': 'source A', 'fields': {'product_name': 'Food A', 'ingredients_text': 'water, sugar'}},
            {'source_name': 'source B', 'fields': {'product_name': 'Food B', 'ingredients_text': 'water, salt'}},
        ],
    })
    assert r.status_code == 200
    data = r.json()
    assert len(data['source_conflicts']) == 2
    assert all('未自动选择' in x['resolution'] for x in data['source_conflicts'])


def test_rule_analysis_does_not_flag_known_fields_as_missing():
    r = client.post('/api/v1/analysis/rules', json={'product': {
        'name': 'Fixture food', 'barcode': '12345678', 'ingredients_text': 'water',
        'nutrition': [{'name': 'energy', 'amount': 10, 'unit': 'kcal', 'basis': '100 g'}],
        'allergens_text': 'none declared', 'source': {'name': 'Fixture source', 'url': 'https://example.invalid/item'},
    }})
    assert r.status_code == 200
    assert r.json()['warnings'] == []
