"""Explainable, conservative food-record checks; never emits a health score."""
from __future__ import annotations
from typing import Any


def _has_value(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, dict, tuple, set)):
        return bool(value)
    return True


def analyze_product(product: dict[str, Any]) -> list[dict[str, str]]:
    """Return transparent data-quality notices based only on supplied fields."""
    rules: list[dict[str, str]] = []

    if not _has_value(product.get("name")):
        rules.append({"code": "missing_product_name", "severity": "info", "field": "name", "message": "未提供商品名称，无法确认商品身份。", "basis": "商品记录的 name 字段为空。"})
    if not _has_value(product.get("barcode")):
        rules.append({"code": "missing_barcode", "severity": "info", "field": "barcode", "message": "未提供条形码，无法仅凭当前记录确认商品唯一性。", "basis": "商品记录的 barcode 字段为空。"})
    if not _has_value(product.get("ingredients_text")) and not _has_value(product.get("ingredients")):
        rules.append({"code": "missing_ingredients", "severity": "warning", "field": "ingredients", "message": "当前记录未提供配料信息；缺失不代表不含某种成分。", "basis": "原始配料文本和结构化配料字段均为空。"})
    if not _has_value(product.get("nutrition")):
        rules.append({"code": "missing_nutrition", "severity": "info", "field": "nutrition", "message": "当前记录未提供营养数据，不能据此比较营养含量。", "basis": "nutrition 字段为空或不存在。"})
    if not _has_value(product.get("allergens_text")) and not _has_value(product.get("allergens")) and not _has_value(product.get("allergens_tags")):
        rules.append({"code": "allergens_unknown", "severity": "warning", "field": "allergens", "message": "未提供过敏原信息；状态为未知，不代表无过敏原。", "basis": "过敏原相关字段均为空或不存在。"})
    source = product.get("source")
    if not isinstance(source, dict) or not _has_value(source.get("url")):
        rules.append({"code": "missing_source", "severity": "warning", "field": "source", "message": "缺少可核验的来源链接，当前记录的来源可追溯性不足。", "basis": "source.url 字段为空或不存在。"})
    elif not _has_value(source.get("name")):
        rules.append({"code": "incomplete_source", "severity": "info", "field": "source", "message": "提供了来源链接，但来源名称缺失。", "basis": "source.url 存在而 source.name 为空。"})

    return rules


def detect_source_conflicts(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Flag exact disagreements between explicitly supplied source records.

    The function reports disagreement only; it does not choose a winner or infer
    that either value is correct. Each record is {source_name, fields: {...}}.
    """
    if len(records) < 2:
        return []
    by_field: dict[str, list[dict[str, Any]]] = {}
    for record in records:
        source_name = str(record.get("source_name") or "未命名来源")
        fields = record.get("fields")
        if not isinstance(fields, dict):
            continue
        for field, value in fields.items():
            if _has_value(value):
                by_field.setdefault(str(field), []).append({"source": source_name, "value": value})
    conflicts = []
    for field, values in by_field.items():
        # Compare normalized string forms; preserve original values in output.
        normalized = {str(item["value"]).strip().casefold() for item in values}
        if len(normalized) > 1 and len(values) > 1:
            conflicts.append({
                "code": "source_value_disagreement",
                "field": field,
                "severity": "review",
                "message": f"不同来源对字段“{field}”提供的值不一致，需要人工核对。",
                "values": values,
                "resolution": "未自动选择任一来源；请核对商品包装、生产商资料及各来源更新时间。",
            })
    return conflicts
