from __future__ import annotations
import os, time, uuid, re, json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import httpx
from fastapi import FastAPI, HTTPException, Query, UploadFile, File, Request, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from sqlalchemy import String, Text, DateTime, JSON, ForeignKey
from app.rules import analyze_product, detect_source_conflicts

APP_VERSION = "0.1.0"
OFF_BASE = "https://world.openfoodfacts.org"
CONTACT_EMAIL = os.getenv("CONTACT_EMAIL", "1989964515@qq.com")
USER_AGENT = os.getenv("OPEN_FOOD_FACTS_USER_AGENT", f"OpenIngredient/0.1.0 ({CONTACT_EMAIL})")
CORS_ORIGINS = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if x.strip()]
app = FastAPI(title="Open Ingredient API", version=APP_VERSION, description="Food product data explorer with source provenance. Not medical advice.")
app.add_middleware(CORSMiddleware, allow_origins=CORS_ORIGINS, allow_credentials=False, allow_methods=["GET","POST","OPTIONS"], allow_headers=["*"])

# In-memory development rate limiter. Production deployments should use a shared store (e.g. Redis).
_hits: dict[str, list[float]] = {}
@app.middleware("http")
async def basic_rate_limit(request: Request, call_next):
    if request.url.path.startswith("/api/") and request.method in {"GET", "POST"}:
        path = request.url.path
        if path.endswith("/products/search"): bucket, ceiling = "search", 8
        elif "/products/barcode/" in path: bucket, ceiling = "barcode", 12
        elif path.startswith("/api/v1/ocr/"): bucket, ceiling = "ocr", 5
        elif path.startswith("/api/v1/contributions"): bucket, ceiling = "contributions", 5
        else: bucket, ceiling = path, int(os.getenv("API_REQUESTS_PER_MINUTE", "60"))
        key = (request.client.host if request.client else "unknown") + ":" + bucket
        now = time.time(); recent = [t for t in _hits.get(key, []) if now - t < 60]
        limit = min(int(os.getenv("API_REQUESTS_PER_MINUTE", "60")), ceiling)
        if len(recent) >= limit:
            return JSONResponse(status_code=429, content={"error":{"code":"rate_limited","message":"请求过于频繁，请稍后重试。"}})
        recent.append(now); _hits[key] = recent
    return await call_next(request)

class RuleAnalysisIn(BaseModel):
    product: dict[str, Any] = Field(default_factory=dict)
    source_records: list[dict[str, Any]] = Field(default_factory=list, max_length=20)

class ContributionIn(BaseModel):
    product_barcode: str | None = Field(default=None, pattern=r"^\d{8,14}$")
    contribution_type: str = Field(pattern="^(new_product|ingredient_correction|image_update)$")
    payload: dict[str, Any]
    note: str | None = Field(default=None, max_length=1000)

# Local-first persistent database: SQLite by default; DATABASE_URL can select PostgreSQL.
DATA_DIR = Path(os.getenv("DATA_DIR", ".data")); DATA_DIR.mkdir(parents=True, exist_ok=True)
DATABASE_URL = os.getenv("DATABASE_URL") or f"sqlite:///{(DATA_DIR / 'open_ingredient.db').resolve()}"
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = "postgresql+psycopg://" + DATABASE_URL[len("postgres://"):]
elif DATABASE_URL.startswith("postgresql://") and "+psycopg" not in DATABASE_URL:
    DATABASE_URL = "postgresql+psycopg://" + DATABASE_URL[len("postgresql://"):]
_engine_kwargs = {"connect_args": {"check_same_thread": False}} if DATABASE_URL.startswith("sqlite:") else {"pool_pre_ping": True}
engine = create_engine(DATABASE_URL, **_engine_kwargs)
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
class Base(DeclarativeBase): pass
class ProductRecord(Base):
    __tablename__ = "products"
    barcode: Mapped[str] = mapped_column(String(32), primary_key=True)
    name: Mapped[str] = mapped_column(String(500), default="")
    brand: Mapped[str] = mapped_column(String(500), default="")
    category: Mapped[str] = mapped_column(Text, default="")
    ingredients_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    allergens_raw: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_updated_at: Mapped[str | None] = mapped_column(String(40), nullable=True)
    last_fetched_at: Mapped[str] = mapped_column(String(40))
    raw_payload: Mapped[dict] = mapped_column(JSON, default=dict)

class ProductSourceRecord(Base):
    __tablename__ = "product_sources"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    product_barcode: Mapped[str] = mapped_column(ForeignKey("products.barcode", ondelete="CASCADE"), index=True)
    source_name: Mapped[str] = mapped_column(String(200))
    source_url: Mapped[str] = mapped_column(Text)
    license_name: Mapped[str | None] = mapped_column(String(200), nullable=True)
    retrieved_at: Mapped[str] = mapped_column(String(40))
    source_updated_at: Mapped[str | None] = mapped_column(String(40), nullable=True)

class ProductIngredientRecord(Base):
    __tablename__ = "product_ingredients"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    product_barcode: Mapped[str] = mapped_column(ForeignKey("products.barcode", ondelete="CASCADE"), index=True)
    position: Mapped[int] = mapped_column()
    name: Mapped[str] = mapped_column(String(500))
    original_text: Mapped[str | None] = mapped_column(Text, nullable=True)
    source_url: Mapped[str | None] = mapped_column(Text, nullable=True)

class ProductNutritionRecord(Base):
    __tablename__ = "product_nutrition"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    product_barcode: Mapped[str] = mapped_column(ForeignKey("products.barcode", ondelete="CASCADE"), index=True)
    nutrient_name: Mapped[str] = mapped_column(String(200))
    amount: Mapped[str] = mapped_column(String(100))
    unit: Mapped[str] = mapped_column(String(50))
    basis: Mapped[str] = mapped_column(String(100))
    original_key: Mapped[str | None] = mapped_column(String(200), nullable=True)
    source_url: Mapped[str | None] = mapped_column(Text, nullable=True)

class ContributionRecord(Base):
    __tablename__ = "contributions"
    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    product_barcode: Mapped[str | None] = mapped_column(String(32), nullable=True, index=True)
    contribution_type: Mapped[str] = mapped_column(String(40))
    payload: Mapped[dict] = mapped_column(JSON)
    note: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(16), default="pending", index=True)
    created_at: Mapped[str] = mapped_column(String(40))
    reviewed_at: Mapped[str | None] = mapped_column(String(40), nullable=True)
    review_note: Mapped[str | None] = mapped_column(Text, nullable=True)
if os.getenv("APP_ENV", "development") != "production" and os.getenv("ALEMBIC_RUNNING") != "1":
    Base.metadata.create_all(engine)
def utcnow(): return datetime.now(timezone.utc).isoformat()
def contribution_dict(row: ContributionRecord):
    return {"id":row.id,"product_barcode":row.product_barcode,"contribution_type":row.contribution_type,"payload":row.payload,"note":row.note,"status":row.status,"created_at":row.created_at,"reviewed_at":row.reviewed_at,"review_note":row.review_note}
def source_meta(url: str, retrieved_at: str | None = None):
    return {"name":"Open Food Facts", "url":url, "license":"ODbL 1.0 (database); individual contents may use DbCL; image-specific CC BY-SA terms must be checked", "retrieved_at":retrieved_at or utcnow()}
def product_fields(product: dict[str, Any], barcode: str | None = None):
    n = product.get("nutriments") or {}
    nutrition=[]
    fields=[("energy-kcal_100g","能量","kcal","每100 g"),("fat_100g","脂肪","g","每100 g"),("saturated-fat_100g","饱和脂肪","g","每100 g"),("carbohydrates_100g","碳水化合物","g","每100 g"),("sugars_100g","糖","g","每100 g"),("fiber_100g","膳食纤维","g","每100 g"),("proteins_100g","蛋白质","g","每100 g"),("salt_100g","盐","g","每100 g"),("sodium_100g","钠","g","每100 g")]
    for key,label,unit,basis in fields:
        if n.get(key) is not None: nutrition.append({"name":label,"amount":n.get(key),"unit":unit,"basis":basis,"original_key":key})
    ingredients_text = product.get("ingredients_text") or product.get("ingredients_text_zh") or ""
    return {"barcode":product.get("code") or barcode, "name":product.get("product_name") or product.get("product_name_zh") or "", "brand":product.get("brands") or "", "category":product.get("categories") or "", "image_url":product.get("image_front_url") or product.get("image_url"), "ingredients_text":ingredients_text, "ingredients":product.get("ingredients") or [], "allergens_text":product.get("allergens") or product.get("allergens_tags") or None, "nutrition":nutrition, "source":source_meta(product.get("url") or f"{OFF_BASE}/product/{product.get('code') or barcode}"), "source_updated_at":product.get("last_modified_t") or None, "fetched_at":utcnow(), "data_completeness": {"has_ingredients":bool(ingredients_text),"has_nutrition":bool(nutrition),"has_allergens":bool(product.get("allergens") or product.get("allergens_tags")),"has_image":bool(product.get("image_front_url") or product.get("image_url"))}, "disclaimer":"上游数据由贡献者提供，可能不完整或不准确；请核对商品包装及生产商最新信息。"}
async def off_get(path: str, params: dict | None = None):
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(8.0), headers={"User-Agent":USER_AGENT,"Accept":"application/json"}) as client:
            r=await client.get(f"{OFF_BASE}{path}",params=params); r.raise_for_status(); return r.json()
    except httpx.TimeoutException: raise HTTPException(504, detail={"code":"upstream_timeout","message":"食品数据源响应超时，请稍后重试。"})
    except httpx.HTTPStatusError as e:
        if e.response.status_code in {429, 503}: raise HTTPException(503, detail={"code":"upstream_rate_limited","message":"上游数据源暂时限流或不可用，请稍后重试。"})
        raise HTTPException(502, detail={"code":"upstream_error","message":"暂时无法获取上游食品数据。"})
    except (httpx.HTTPError, ValueError): raise HTTPException(502, detail={"code":"upstream_unavailable","message":"食品数据源暂不可用，请检查网络后重试。"})

@app.exception_handler(HTTPException)
async def http_error(request, exc: HTTPException):
    detail=exc.detail
    if isinstance(detail, dict) and "code" in detail: body={"error":detail}
    else: body={"error":{"code":f"http_{exc.status_code}","message":str(detail)}}
    return JSONResponse(status_code=exc.status_code,content=body)
@app.get("/health")
def health(): return {"status":"ok","version":APP_VERSION,"time":utcnow()}
@app.get("/api/v1/products/search")
async def search_products(q: str=Query(min_length=1,max_length=120), page:int=Query(1,ge=1), page_size:int=Query(12,ge=1,le=24)):
    q=q.strip()
    if not q: raise HTTPException(422,detail="搜索词不能为空")
    # OFF legacy CGI search supports text queries; requests are debounced by the client and rate-limited here.
    data=await off_get("/cgi/search.pl",{"search_terms":q,"search_simple":1,"action":"process","json":1,"page":page,"page_size":page_size,"fields":"code,product_name,product_name_zh,brands,categories,image_front_url,image_url,ingredients_text,allergens,nutriments,last_modified_t,url"})
    products=[product_fields(x) for x in data.get("products",[]) if isinstance(x,dict)]
    return {"items":products,"page":page,"page_size":page_size,"count":data.get("count"),"source":source_meta(f"{OFF_BASE}/cgi/search.pl?search_terms={q}"),"notice":"搜索结果来自 Open Food Facts；未对缺失字段进行补造。"}
@app.get("/api/v1/products/barcode/{barcode}")
async def product_by_barcode(barcode: str):
    if not re.fullmatch(r"\d{8,14}",barcode): raise HTTPException(422,detail="条形码格式无效，应为 8–14 位数字。")
    data=await off_get(f"/api/v3.6/product/{barcode}.json",{"fields":"code,product_name,product_name_zh,brands,categories,image_front_url,image_url,ingredients_text,ingredients,allergens,allergens_tags,nutriments,last_modified_t,url"})
    if data.get("status") != 1 or not data.get("product"): raise HTTPException(404,detail={"code":"product_not_found","message":"未找到该条形码对应的商品；这不代表商品不存在。"})
    return product_fields(data["product"],barcode)
@app.get("/api/v1/products/compare")
async def compare_products(ids: str=Query(description="两个逗号分隔的条形码")):
    codes=[x.strip() for x in ids.split(",") if x.strip()]
    if len(codes)!=2 or any(not re.fullmatch(r"\d{8,14}",x) for x in codes): raise HTTPException(422,detail="必须提供两个有效条形码。")
    results=[]
    for code in codes:
        try: results.append(await product_by_barcode(code))
        except HTTPException as e:
            if e.status_code==404: results.append({"barcode":code,"name":"","error":"not_found"})
            else: raise
    return {"items":results,"comparison_note":"只比较来源明确且单位、基准一致的字段；缺失数据不代表更好或更差。"}
@app.get("/api/v1/products/{barcode}")
async def product_detail(barcode: str): return await product_by_barcode(barcode)
@app.post("/api/v1/analysis/rules")
def analyze_rules(item: RuleAnalysisIn):
    """Explain data gaps and cross-source disagreements without health scoring."""
    warnings = analyze_product(item.product)
    conflicts = detect_source_conflicts(item.source_records)
    return {
        "rules_version": "1.0",
        "health_score": None,
        "warnings": warnings,
        "source_conflicts": conflicts,
        "summary": {
            "warning_count": sum(1 for x in warnings if x["severity"] == "warning"),
            "info_count": sum(1 for x in warnings if x["severity"] == "info"),
            "conflict_count": len(conflicts),
        },
        "notice": "这是数据完整性与来源一致性提示，不是健康、安全或医疗评分；系统不会自动判定冲突值的真伪。",
    }

@app.get("/api/v1/filters")
def filters(): return {"filters":[{"id":"has_ingredients","label":"有配料表"},{"id":"has_nutrition","label":"有营养信息"},{"id":"has_allergens","label":"有过敏原标签"}],"note":"筛选仅基于来源明确提供的字段；缺失过敏原信息不等于无过敏原。"}
@app.get("/api/v1/ingredients/{ingredient_id}")
def ingredient_detail(ingredient_id: str):
    name=ingredient_id.replace("-"," ").strip()
    return {"canonical_name":name,"original_name":name,"aliases":[],"category":None,"description":"现有资料不足，无法确认该成分的具体用途或在特定商品中的作用。","evidence_status":"insufficient_evidence","source_ids":[],"ai_generated":False,"note":"当前版本未连接经核验的成分知识库；此页面不将模型推断当作事实。"}
@app.get("/api/v1/products/{barcode}/sources")
async def product_sources(barcode: str):
    product=await product_by_barcode(barcode); return {"barcode":barcode,"sources":[product["source"]],"fetched_at":product["fetched_at"],"source_updated_at":product["source_updated_at"]}
@app.post("/api/v1/ocr/ingredients")
async def ocr_ingredients(file: UploadFile=File(...)):
    allowed={"image/jpeg","image/png","image/webp"}
    if file.content_type not in allowed: raise HTTPException(415,detail="仅支持 JPG、PNG、WebP 图片。")
    raw=await file.read(8*1024*1024+1)
    if len(raw)>8*1024*1024: raise HTTPException(413,detail="图片不能超过 8 MB。")
    try:
        from PIL import Image
        import io
        im=Image.open(io.BytesIO(raw)); im.verify()
    except Exception: raise HTTPException(422,detail="文件不是有效图片或图片已损坏。")
    # Local Tesseract is free and keeps the uploaded image on this request only.
    # The image bytes are never written to disk or returned to the client.
    provider = os.getenv("OCR_PROVIDER", "tesseract").strip().lower()
    if provider == "tesseract":
        try:
            import io
            import pytesseract
            from PIL import Image, ImageOps
            with Image.open(io.BytesIO(raw)) as image:
                image = ImageOps.exif_transpose(image).convert("RGB")
                # Bound CPU/memory use by downscaling very large photos.
                image.thumbnail((2400, 2400))
                text = pytesseract.image_to_string(image, lang=os.getenv("TESSERACT_LANG", "chi_sim+eng"), timeout=15).strip()
            return {"draft_id":str(uuid.uuid4()),"status":"draft_ready" if text else "manual_fallback","text":text,"provider":"tesseract","is_mock":False,"message":"OCR 结果仅为草稿，必须人工核对；识别错误不能作为商品标签事实。" if text else "未识别到可用文本，请手动录入配料表。","requires_user_confirmation":True,"image_persisted":False}
        except Exception:
            # Missing binary/language data or OCR runtime errors fall back safely.
            pass
    return {"draft_id":str(uuid.uuid4()),"status":"manual_fallback","text":"","provider":"none","is_mock":False,"message":"本地 OCR 不可用。请手动录入或校对配料表；未识别文本不会被伪造。","requires_user_confirmation":True,"image_persisted":False}
@app.post("/api/v1/contributions",status_code=202)
def submit_contribution(item: ContributionIn, request: Request):
    if len(json.dumps(item.payload,ensure_ascii=False))>20000: raise HTTPException(413,detail="提交内容过大。")
    record={"id":str(uuid.uuid4()),"product_barcode":item.product_barcode,"contribution_type":item.contribution_type,"payload":item.payload,"note":item.note,"status":"pending","created_at":utcnow(),"reviewed_at":None,"review_note":None}
    with SessionLocal() as db:
        db.add(ContributionRecord(**record)); db.commit()
    return {"id":record["id"],"status":"pending","created_at":record["created_at"],"message":"已进入待审核队列。该提交不会直接修改正式商品数据。"}
@app.get("/api/v1/contributions/{contribution_id}")
def contribution_status(contribution_id: str):
    with SessionLocal() as db:
        row=db.get(ContributionRecord, contribution_id)
        if not row: raise HTTPException(404,detail="未找到该提交记录。")
        return {k:contribution_dict(row)[k] for k in ("id","status","created_at","reviewed_at","review_note")}
@app.post("/api/v1/admin/contributions/{contribution_id}/review")
def review_contribution(contribution_id: str, request: Request, status: str=Query(pattern="^(approved|rejected)$"), note: str="", x_admin_secret: str|None=Header(default=None)):
    secret=os.getenv("ADMIN_AUTH_SECRET")
    if not secret or not x_admin_secret or x_admin_secret != secret: raise HTTPException(401,detail="需要有效的审核权限。")
    with SessionLocal() as db:
        row=db.get(ContributionRecord, contribution_id)
        if not row: raise HTTPException(404,detail="未找到该提交记录。")
        if row.status!="pending": raise HTTPException(409,detail="只有待审核提交可以变更状态。")
        row.status=status; row.review_note=note[:1000]; row.reviewed_at=utcnow(); db.commit()
        return {"id":row.id,"status":row.status,"reviewed_at":row.reviewed_at}
@app.get("/api/v1/about/data-sources")
def data_sources():
    return {"sources":[{"name":"Open Food Facts","api":"https://openfoodfacts.github.io/openfoodfacts-server/api/","website":"https://world.openfoodfacts.org/","database_license":"ODbL 1.0","contents_license":"DbCL 1.0 (per source documentation)","image_license":"CC BY-SA (verify the applicable version and each image/context)","limits":"Official documentation currently states 10 search requests/minute/IP and 15 product-read requests/minute/IP; no search-as-you-type.","checked_at":"2026-10-23","notes":"API terms, attribution, share-alike and any image-specific rights must be reviewed before production redistribution."}],"project_code_license":"MIT does not relicense upstream data or images."}
