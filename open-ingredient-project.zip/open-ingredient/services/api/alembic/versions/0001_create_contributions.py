"""Create contribution moderation table.

Revision ID: 0001
Revises:
Create Date: 2026-10-23
"""
from alembic import op
import sqlalchemy as sa
revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "contributions",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("product_barcode", sa.String(length=32), nullable=True),
        sa.Column("contribution_type", sa.String(length=40), nullable=False),
        sa.Column("payload", sa.JSON(), nullable=False),
        sa.Column("note", sa.Text(), nullable=True),
        sa.Column("status", sa.String(length=16), nullable=False, server_default="pending"),
        sa.Column("created_at", sa.String(length=40), nullable=False),
        sa.Column("reviewed_at", sa.String(length=40), nullable=True),
        sa.Column("review_note", sa.Text(), nullable=True),
    )
    op.create_index("ix_contributions_product_barcode", "contributions", ["product_barcode"])
    op.create_index("ix_contributions_status", "contributions", ["status"])

def downgrade():
    op.drop_index("ix_contributions_status", table_name="contributions")
    op.drop_index("ix_contributions_product_barcode", table_name="contributions")
    op.drop_table("contributions")
