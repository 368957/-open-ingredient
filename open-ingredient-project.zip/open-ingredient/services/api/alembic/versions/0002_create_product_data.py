"""Create normalized food product, source, ingredient and nutrition tables.

Revision ID: 0002
Revises: 0001
"""
from alembic import op
import sqlalchemy as sa
revision = "0002"
down_revision = "0001"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table(
        "products",
        sa.Column("barcode", sa.String(length=32), primary_key=True),
        sa.Column("name", sa.String(length=500), nullable=False, server_default=""),
        sa.Column("brand", sa.String(length=500), nullable=False, server_default=""),
        sa.Column("category", sa.Text(), nullable=False, server_default=""),
        sa.Column("ingredients_text", sa.Text(), nullable=True),
        sa.Column("allergens_raw", sa.Text(), nullable=True),
        sa.Column("source_updated_at", sa.String(length=40), nullable=True),
        sa.Column("last_fetched_at", sa.String(length=40), nullable=False),
        sa.Column("raw_payload", sa.JSON(), nullable=False),
    )
    op.create_table(
        "product_sources",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("product_barcode", sa.String(length=32), sa.ForeignKey("products.barcode", ondelete="CASCADE"), nullable=False),
        sa.Column("source_name", sa.String(length=200), nullable=False),
        sa.Column("source_url", sa.Text(), nullable=False),
        sa.Column("license_name", sa.String(length=200), nullable=True),
        sa.Column("retrieved_at", sa.String(length=40), nullable=False),
        sa.Column("source_updated_at", sa.String(length=40), nullable=True),
    )
    op.create_index("ix_product_sources_product_barcode", "product_sources", ["product_barcode"])
    op.create_table(
        "product_ingredients",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("product_barcode", sa.String(length=32), sa.ForeignKey("products.barcode", ondelete="CASCADE"), nullable=False),
        sa.Column("position", sa.Integer(), nullable=False),
        sa.Column("name", sa.String(length=500), nullable=False),
        sa.Column("original_text", sa.Text(), nullable=True),
        sa.Column("source_url", sa.Text(), nullable=True),
    )
    op.create_index("ix_product_ingredients_product_barcode", "product_ingredients", ["product_barcode"])
    op.create_table(
        "product_nutrition",
        sa.Column("id", sa.String(length=36), primary_key=True),
        sa.Column("product_barcode", sa.String(length=32), sa.ForeignKey("products.barcode", ondelete="CASCADE"), nullable=False),
        sa.Column("nutrient_name", sa.String(length=200), nullable=False),
        sa.Column("amount", sa.String(length=100), nullable=False),
        sa.Column("unit", sa.String(length=50), nullable=False),
        sa.Column("basis", sa.String(length=100), nullable=False),
        sa.Column("original_key", sa.String(length=200), nullable=True),
        sa.Column("source_url", sa.Text(), nullable=True),
    )
    op.create_index("ix_product_nutrition_product_barcode", "product_nutrition", ["product_barcode"])

def downgrade():
    op.drop_index("ix_product_nutrition_product_barcode", table_name="product_nutrition")
    op.drop_table("product_nutrition")
    op.drop_index("ix_product_ingredients_product_barcode", table_name="product_ingredients")
    op.drop_table("product_ingredients")
    op.drop_index("ix_product_sources_product_barcode", table_name="product_sources")
    op.drop_table("product_sources")
    op.drop_table("products")
