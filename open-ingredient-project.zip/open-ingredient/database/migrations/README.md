# 数据库迁移

当前可执行的 Alembic 迁移位于 `services/api/alembic/versions/`。首个迁移创建贡献审核表；商品、成分、营养、来源、证据、分析结果和审计事件模型尚未全部实现。

本地默认使用 `.data/open_ingredient.db` SQLite。生产环境设置 `DATABASE_URL` 指向 PostgreSQL，并在发布前执行：

```bash
cd services/api
alembic upgrade head
alembic current
```

生产环境建议设置 `APP_ENV=production`，应用启动时不会自动创建表；必须先运行迁移。不要把数据库凭据提交到 Git。
