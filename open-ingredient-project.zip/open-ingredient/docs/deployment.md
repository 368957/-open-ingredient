# 部署与 APK 构建

## API Docker

```bash
cd services/api
docker build -t open-ingredient-api .
docker run --rm -p 8000:8000 \
  -e CONTACT_EMAIL='1989964515@qq.com' \
  -e OPEN_FOOD_FACTS_USER_AGENT='OpenIngredient/0.1.0 (1989964515@qq.com)' \
  -e OCR_PROVIDER='tesseract' \
  -e CORS_ORIGINS='https://your-web-domain.example' \
  -e ADMIN_AUTH_SECRET='replace-with-a-long-random-secret' \
  -v oi-data:/app/.data open-ingredient-api
```

注意：默认本地数据库为 SQLite；生产环境应配置 PostgreSQL 的 `DATABASE_URL`，先执行 `cd services/api && alembic upgrade head`，并替换进程内限流为共享限流。不可把示例域名或示例密钥用于生产。

## Web

```bash
npm install
npm run build:web
```

构建产物位于 `apps/web/dist`。部署静态站点前设置 `VITE_API_BASE_URL` 为实际 HTTPS API 地址；Vite 的变量在构建时写入客户端包，不得放入服务端秘密。

## Android APK（EAS）

1. 安装 Node.js 与 npm，进入 `apps/mobile` 并执行 `npm install`。
2. 构建前设置 `EXPO_PUBLIC_API_BASE_URL` 为公网 HTTPS API 地址，不能使用 `localhost`。当前 `10.0.2.2` 仅适用于 Android 模拟器访问宿主机；真机本地测试应使用电脑在同一 Wi-Fi 下的局域网 IP。
3. 登录 Expo/EAS：`npx eas-cli login`（需用户自己的账号）。
4. 配置项目：`npx eas-cli build:configure`。
5. 构建预览 APK：`npx eas-cli build --platform android --profile preview`。
6. 下载 EAS 返回的构建产物，检查 APK 文件和构建日志，并安装到真机测试扫码权限、查询、网络失败和图片选择流程。

EAS 账号、构建配额、签名密钥与外部 API 地址需要用户配置；本项目没有替用户创建账号、付费资源或签名密钥。构建命令本身不代表 APK 已成功生成。

## 发布前检查与回滚

- 配置 HTTPS、域名、最小 CORS 白名单、数据库、备份/恢复演练、强随机管理员秘密和速率限制。
- 验证健康检查、OpenAPI、真实上游查询、错误/限流处理和审核权限。
- 先部署候选版本并执行 smoke tests；保留上一个已验证的 Web/API 镜像与数据库备份，失败时回滚镜像并按迁移兼容性恢复数据库。
- 当前未配置托管平台、域名、数据库或凭据，尚未进行真实公网部署。

## Render 公网预览（免费方案，有数据保留限制）

仓库根目录提供 `render.yaml`，可在 Render Dashboard 选择 **New → Blueprint**，连接本项目仓库并部署。Blueprint 包含 API、静态 Web 和 PostgreSQL；API 启动时先执行 Alembic 迁移，之后才启动 Uvicorn，端口读取 Render 提供的 `PORT`。

**重要限制：** Render 免费 Web 服务可能休眠；免费 PostgreSQL 数据库仅保留 30 天，到期后会被删除。此配置只适合公开预览和验收，不适合长期保存贡献记录。长期公开运行前，必须在 Render 将数据库升级为付费计划或迁移到其他有持续保留能力的 PostgreSQL 服务，并确认费用。未获得明确的付费授权，不应升级付费资源。当前限流仍为单进程内存实现，不适合作为抗滥用的生产级防护。

部署后验证：

1. API `https://<api-host>/health` 返回 `{"status":"ok"}`。
2. API `https://<api-host>/openapi.json` 可访问。
3. Web 首页能加载，浏览器网络面板中 API 请求发往 `VITE_API_BASE_URL` 对应的 HTTPS 域名。
4. 在上游可访问的环境测试商品搜索、条码查询、比较、OCR（识别结果必须人工确认）和贡献提交。
5. 确认数据库已执行到 Alembic `0002`，且 `ADMIN_AUTH_SECRET` 已自动生成；不要公开该值。

若 Render Blueprint 对 Docker 构建上下文或跨服务变量校验失败，应先修复 Blueprint 并重新通过 CI，不要以部署页面显示“已创建”代替可用性测试。
