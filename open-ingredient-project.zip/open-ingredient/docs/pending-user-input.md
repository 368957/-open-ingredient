# 需要用户后续补充或确认的事项

此清单按“先本地可运行、后发布”的配置生成。当前没有创建远程仓库、云资源或付费服务。

## 本地开发阶段

- [ ] 在能运行 Node.js 的电脑上安装 Web 依赖；当前开发容器访问 npm registry 超时，Web 构建未能完成。
- [ ] 在目标运行电脑安装 Tesseract OCR 及 `chi_sim`、`eng` 语言包；Docker 镜像定义已包含这些包，但 Docker 当前环境不可用，镜像未构建验证。
- [ ] 本地 API 与 Web 启动后，执行真实商品搜索和条码查询；当前容器 DNS 无法解析 `world.openfoodfacts.org`，真实上游请求未验证。

## Open Food Facts

- [ ] 联系邮箱已配置为 `1989964515@qq.com`。
- [ ] 由项目维护者阅读官方条款并提交官方 API usage form；此操作尚未执行。官方 API 文档：https://openfoodfacts.github.io/openfoodfacts-server/api/
- [ ] 上线前确认数据署名、ODbL/DbCL 义务以及每张商品图片适用的许可证和图案相关权利。

## GitHub 开源发布

- [x] 用户已创建 GitHub 仓库。
- [x] 用户提供仓库地址：`https://github.com/368957/-open-ingredient.git`。
- [ ] 当前 GitHub 连接器对该地址返回 404，无法确认是仓库路径不正确、仓库为私有，还是连接器没有访问权限；请确认仓库可见性与连接权限后再推送，避免写入错误目标。
- [ ] 在 GitHub Actions 中查看真实 CI 结果。工作流已配置 API 测试、数据库迁移和 Web 构建，但尚未运行。

## 公网 Web 与 Android APK

- [x] 用户允许在测试通过后进行公网部署；已添加 Render Blueprint（`render.yaml`），包含 API、静态 Web 和 PostgreSQL。
- [ ] 真实部署前仍需先推送代码、运行 GitHub Actions 并完成 Web 构建；当前本地 npm registry DNS 失败，前端构建无法在本环境验证。
- [ ] Render 免费 PostgreSQL 会在 30 天后到期并删除数据；目前 Blueprint 仅用于公开预览。长期保存贡献记录前，需用户明确批准付费数据库或选择其他持久化方案。
- [ ] Render 账号连接、创建资源和最终公网健康检查尚未完成。生产数据库连接由 Blueprint 的 `DATABASE_URL` 注入；Alembic 在 API 容器启动时执行。
- [ ] Android APK 需要 Expo/EAS 账户及构建权限；需要公网 HTTPS API 地址或可访问的局域网地址。当前未构建 APK。
- [ ] LLM 按当前配置暂缓，不需要提供 API 密钥；在接入前应先建立有来源的成分证据库和输出验证规则。

## 明确未交付

- 公网 URL、签名 APK、生产 PostgreSQL 实例尚未创建；本地 Git 尚未关联远程仓库。
- 尚未实现成分证据与规则审计数据库模型、完整证据知识库、生产级身份认证和共享限流。
