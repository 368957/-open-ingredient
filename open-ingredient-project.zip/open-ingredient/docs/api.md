# API 使用说明

开发地址默认为 `http://localhost:8000`，OpenAPI UI 在 `/docs`。

- `GET /health`
- `GET /api/v1/products/search?q={query}&page=1&page_size=12`
- `GET /api/v1/products/barcode/{barcode}`
- `GET /api/v1/products/{barcode}`（条码商品详情别名）
- `GET /api/v1/products/{barcode}/sources`
- `GET /api/v1/products/compare?ids={barcode1},{barcode2}`
- `GET /api/v1/ingredients/{ingredient_id}`
- `GET /api/v1/filters`
- `GET /api/v1/about/data-sources`
- `POST /api/v1/ocr/ingredients`（multipart 字段 `file`；默认本地 Tesseract OCR，输出必须人工确认，图片不持久化）
- `POST /api/v1/contributions`
- `GET /api/v1/contributions/{contribution_id}`
- `POST /api/v1/admin/contributions/{id}/review?status=approved|rejected`（请求头 `X-Admin-Secret`；仅当设置 `ADMIN_AUTH_SECRET` 后可用）

统一错误响应示例：`{"error":{"code":"http_404","message":"..."}}`。外部 API 超时会返回 504，上游不可用会返回 502/503。条码限制为 8–14 位数字。生产环境必须增加端点级共享限流、审核者身份体系与审计日志。
- `POST /api/v1/analysis/rules`（请求体 `{ "product": {...}, "source_records": [{"source_name":"...", "fields": {...}}] }`；返回缺失字段提示和跨来源值不一致列表，不输出健康评分）

## 规则分析示例

```json
{
  "product": {
    "name": "示例食品",
    "barcode": "12345678",
    "ingredients_text": "water, sugar",
    "source": {"name": "示例来源", "url": "https://example.invalid/product"}
  },
  "source_records": [
    {"source_name": "来源 A", "fields": {"product_name": "示例食品"}},
    {"source_name": "来源 B", "fields": {"product_name": "示例食品 2"}}
  ]
}
```

规则引擎仅检查传入字段；`source_records` 由调用方提供，不代表系统已独立核验这些来源。发现字段值不一致时只提示人工核对，不会自动选定正确值。
