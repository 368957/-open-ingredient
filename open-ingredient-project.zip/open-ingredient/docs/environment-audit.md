# 环境审计

- 审计日期：2026-10-23（当前执行环境）。
- 工作目录：`/mnt/data/open-ingredient`，开始时为新建目录，没有既有 Git 仓库文件可覆盖。
- Node.js：`v22.16.0`；npm：`10.9.2`。
- Python：`3.13.5`。
- Git：`2.47.3`。
- Java：OpenJDK `21.0.12`。
- Docker：命令未找到，不可用。
- Tesseract OCR：系统已安装；中文简体（chi_sim）和英文（eng）语言包可用。
- SQLAlchemy：2.0.50；Alembic：1.18.4；pytesseract：0.3.13。
- Android SDK/模拟器：尚未核验到可用安装；不能据此声称 APK 可在当前环境构建或真机验证。
- 依赖网络访问：npm registry 请求超时，离线缓存缺少 @types/react，Web 依赖安装未完成；Open Food Facts 真实 API 请求尚未完成验证。
- GitHub 仓库权限、部署平台、域名、托管 PostgreSQL、OCR/LLM API 密钥、EAS 账号和签名凭据：未提供，未创建付费资源。

## 技术决策

按需求文档使用 React + TypeScript + Vite、Expo React Native、FastAPI。本地贡献数据默认持久化到 SQLite；SQLAlchemy 模型、PostgreSQL URL 适配和 Alembic 初始贡献表迁移已建立。完整商品/成分/营养/证据数据模型及生产 PostgreSQL 配置尚未完成。

## 阻塞与风险

1. 真实 OCR 和 LLM 服务未配置；OCR 使用人工输入回退，AI 解释不输出无来源的事实。
2. 需要扩展商品、成分、营养、来源、证据和分析结果的数据模型，并为生产 PostgreSQL 配置实际连接和迁移。
3. 需要生产级持久限流、认证、审核者身份管理和滥用处理。
4. 需要在实际环境安装依赖并执行测试、Web 构建、Expo APK 构建。
5. 联系邮箱已配置为 1989964515@qq.com；尚未提交 Open Food Facts API usage form，需阅读条款并完成登记。
6. 需要用户提供/授权 GitHub 仓库、部署平台、域名、数据库、OCR/LLM 服务、EAS 和签名相关设置，才能完成真实公网发布和 APK 交付。
