# 数据来源与许可证核查

- 核查日期：2026-10-23。
- 官方 API 文档：https://openfoodfacts.github.io/openfoodfacts-server/api/
- 官方许可指南：https://openfoodfacts.github.io/documentation/docs/Product-Opener/api/tutorials/license-be-on-the-legal-side/
- 数据网站：https://world.openfoodfacts.org/

## 核查到的官方要点

官方 API 文档标注 v3 为当前推荐的新集成版本，v2 仍兼容但已弃用；官方文档同时指出全文搜索在 v2 server API 中不可用，旧式 `/cgi/search.pl` 可进行文本搜索。当前本项目使用 `/cgi/search.pl` 做名称/品牌搜索、v3.6 商品端点做条码查询。

官方文档当前列出的限流包括：商品读取请求每 IP 每分钟 15 次；搜索请求每 IP 每分钟 10 次。不得采用无节制的按键即搜；应配置自定义 User-Agent，格式建议为 `AppName/Version (ContactEmail)`。本项目 Web 搜索通过表单提交，不做搜索即输入请求，但生产环境仍应增加更严格的端点级共享限流和缓存。

许可方面，官方说明数据库受 Open Database License (ODbL) 约束，单项内容受 Database Contents License (DbCL) 约束，商品图片受 CC BY-SA 许可约束；具体图片适用的许可证版本和包装图案相关权利仍需逐项核对。具体数据、图片及数据库组合的再分发义务需在发布前逐项确认；项目 MIT 许可证不覆盖这些外部内容。

## 本项目字段使用

请求字段包括商品代码、名称、品牌、类别、前包装图片 URL、配料原文、结构化配料、过敏原、营养信息、上游修改时间和来源 URL。接口按请求时获取，不做大规模抓取或批量打包外部商品数据。来源对象包含名称、来源 URL、许可证说明和本系统获取时间。

## 未完成的合规事项

- 未提交 Open Food Facts API usage form；需要确认项目联系邮箱和应用识别信息。
- 未对每张外部图片进行独立权利审查；生产发布前需核对图片许可和署名要求。
- 当前 API 适配器尚未实现生产级缓存、共享限流和完整的上游许可证元数据存储。
- 发布前应重新阅读最新条款并记录核查结果。
