# 测试报告

- 报告日期：2026-10-23。
- 当前状态：后端单元/API 测试通过；Alembic 空数据库升级通过；Render Blueprint YAML 结构解析通过。Web 生产构建、Android APK、真实上游 API 和真机测试未执行。

## 环境检查

- Node.js v22.16.0、npm 10.9.2、Python 3.13.5 可用。
- Docker 未安装/不可用；Android SDK/模拟器未确认。
- 系统 Tesseract 已安装，中文简体和英文语言包可用；pytesseract、SQLAlchemy、Alembic 在当前执行环境可导入。
- `npm install --no-audit --no-fund` 超时；`npm install --offline` 失败，缺少 `@types/react` 的缓存包，故 Web 构建未执行。全局 `tsc` 的语法检查没有发现 TS1xxx 语法诊断，但类型检查无法完成，因为 React、Expo、Vite 等项目依赖未安装。

## 已执行测试

- `PYTHONPATH=. pytest -q`（目录 `services/api`）：**12 passed**。包含健康检查、条码参数、未知过敏原提示、无证据成分说明、非图片上传拒绝、贡献类型校验、比较参数校验、OCR 图片隐私标志、贡献提交与状态查询，以及规则引擎缺失字段、来源冲突和已知字段测试。
- `APP_ENV=production DATABASE_URL=sqlite:////tmp/oi_migration_test.db PYTHONPATH=. alembic upgrade head`：通过，空数据库完成 `0001` 与 `0002` 迁移，创建贡献、商品、来源、结构化配料和营养表。
- `render.yaml` 使用 PyYAML 解析并校验：通过，包含 API Web Service、静态 Web 和 PostgreSQL 三项资源。此项只验证 YAML 结构，不代表 Render 已接受配置或已部署。
- 同一测试数据库执行 `alembic current`：返回 `0002 (head)`。
- 启动 Uvicorn 后请求 `GET /health`：返回 `status=ok`；`GET /openapi.json`：返回 OpenAPI 文档；新增规则分析端点。
- 请求真实 Open Food Facts API：容器 DNS 解析失败，HTTP 000；不计为 API 集成测试通过。

## 未执行或未验证

- Open Food Facts 真实搜索/条码请求、上游超时与限流。当前容器尝试请求官方 API 时 DNS 解析失败（HTTP 000），因此未验证上游连通性。
- OCR 对真实食品包装的识别准确率；自动化测试仅使用合成空白图片验证响应和不保存原图标记。
- PostgreSQL 实例连接、生产迁移、并发和备份恢复。
- Web TypeScript 检查、生产构建、浏览器端到端测试与无障碍检查；规则提示 UI 已接入代码，但因前端依赖安装超时尚未完成浏览器验证。
- Android Expo 类型检查、APK 构建、安装、扫码和网络失败流程真机测试。
- 依赖许可证扫描、CI 实际运行、安全审查、真实公网部署。GitHub 仓库地址目前通过连接器返回 404，远程推送和 CI 触发受阻；本地 npm registry DNS 失败，Web 构建未完成。

## 可复现命令

```bash
cd services/api
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
PYTHONPATH=. pytest -q

# 根目录，联网且 npm registry 可访问时
npm install
npm run build:web
```
