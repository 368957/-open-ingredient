# Shared types

Reserved for shared TypeScript API contracts. Current Web and Expo code define local lightweight types; extracting a versioned shared package remains future work.
