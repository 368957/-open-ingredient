# Open Ingredient

面向中文用户的开源食品商品信息查询工具。优先呈现来源、原始标签和缺失状态；不生成无依据的健康分数，不把未知解释为安全。

> 状态：开发中的首期工程。Web 与 API 具备可运行基础实现；OCR 已接入本地 Tesseract 免费识别适配器，并保留人工录入回退；移动端与生产发布仍需按 `docs/test-report.md` 进行验证。没有真实执行的构建、部署或设备测试不会标记为成功。

## 功能现状

- Web：名称/品牌搜索、条码查询入口、商品详情、营养/配料/过敏原字段、来源信息、双条码对比、OCR 上传回退、匿名贡献待审核、来源与隐私说明。
- Android (Expo)：搜索、手动条码、摄像头条码扫描、商品详情、图片选择和人工录入回退。
- API：FastAPI、OpenAPI、Open Food Facts 数据适配、输入校验、统一错误结构、开发环境速率限制、贡献状态和审核 API。
- 安全边界：AI 解释尚未接入真实模型；没有证据时返回“现有资料不足，无法确认”。

## 技术栈

- Web: React + TypeScript + Vite
- Android: React Native + Expo
- API: Python + FastAPI + httpx
- 数据存储：默认使用 `.data/open_ingredient.db` SQLite；设置 `DATABASE_URL` 可连接 PostgreSQL。Alembic 初始迁移位于 `services/api/alembic/`。目前只迁移了贡献审核表，完整商品/成分/营养证据模型仍未实现。

## 本地启动

### 1. API

```bash
cd services/api
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

API 文档：`http://localhost:8000/docs`；健康检查：`http://localhost:8000/health`。

默认应用联系邮箱为 `1989964515@qq.com`，并据此设置 `OPEN_FOOD_FACTS_USER_AGENT`。使用前仍需完成 Open Food Facts 官方使用登记并复核当前 API 条款。搜索接口不应绑定到每次按键即时请求；前端目前由用户提交表单后搜索。

### 2. Web

```bash
npm install
npm run dev:web
```

打开 `http://localhost:5173`。如 API 地址不同，设置 `VITE_API_BASE_URL`（Web 构建时变量）。若从同一 Wi-Fi 的手机访问，还需将手机访问的电脑局域网源地址加入 API 的 `CORS_ORIGINS`。

### 3. Android

```bash
cd apps/mobile
npm install
npx expo start
```

修改 `apps/mobile/app.json` 中 `extra.apiBaseUrl` 为可被手机访问的 API HTTPS 地址。手机上的 `localhost` 指手机本身，不是开发电脑。扫码需要相机权限。生成 APK 的命令见 `docs/deployment.md`；EAS 账号、签名与网络 API 地址仍需配置。

## 测试

```bash
cd services/api
pip install -r requirements.txt
pytest -q
```

Web 构建：`npm install && npm run build:web`。测试必须实际运行后才能记录结果。参见 `docs/test-report.md`。GitHub 仓库创建步骤见 `docs/github-setup.md`；所有外部阻塞项汇总于 `docs/pending-user-input.md`。目前没有远程仓库。

## 数据来源与许可

项目自有代码采用 MIT。Open Food Facts 数据库、单项内容和图片使用不同许可，不能因本项目采用 MIT 就统一重新许可。使用前请核对官方 API 使用条款、ODbL/DbCL、图片授权和署名义务：

- API: https://openfoodfacts.github.io/openfoodfacts-server/api/
- License guidance: https://openfoodfacts.github.io/documentation/docs/Product-Opener/api/tutorials/license-be-on-the-legal-side/
- Website: https://world.openfoodfacts.org/

详见 `docs/data-sources.md`。

## 生产环境警告

- 当前贡献数据库支持本地 SQLite 和 PostgreSQL 连接，但生产 PostgreSQL 尚未配置；目前只有贡献审核表完成数据库迁移。
- 当前速率限制为进程内存实现，多实例需换成 Redis 等共享限流存储。
- OCR 默认使用本地 Tesseract；需在目标机器安装 Tesseract 和中文/英文语言包。原图不持久保存。
- AI 成分解释未连接真实 LLM 或证据库。
- 公开部署前必须配置 HTTPS、CORS、强随机管理员密钥、持久数据库、备份、日志脱敏、隐私政策和真实服务凭据。
- 不得把真实密钥提交到仓库，也不得将本地 mock 当作真实上游数据。
