# 第三方组件与数据声明

- Open Food Facts：数据库通常受 ODbL 1.0 约束，单项内容可能受 DbCL 1.0 约束；图片通常受 CC BY-SA 3.0 约束。每次发布前核对官方当前条款和具体内容权利。
- React、React DOM、Vite、FastAPI、httpx、Expo、React Native、Pillow 等依赖各自适用许可证。正式发布前应基于锁定依赖版本生成并审阅完整 SBOM/许可证清单；当前未声称已完成自动化许可证扫描。
- Web 使用 Google Fonts 的在线字体 CSS；若需要离线部署，应核对字体许可并改为自托管或系统字体。
